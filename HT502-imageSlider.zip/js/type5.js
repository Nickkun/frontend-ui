$(document).ready(function () {
  $('.pgwSlider').pgwSlider();
});
